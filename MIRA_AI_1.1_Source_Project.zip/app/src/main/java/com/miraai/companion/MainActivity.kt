package com.miraai.companion

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Locale
import java.util.concurrent.TimeUnit

private val bg = Color(0xFF090A14)
private val panel = Color(0xFF191B2A)
private val panel2 = Color(0xFF25283B)
private val pink = Color(0xFFE72BEF)
private val violet = Color(0xFF8757F5)
private val cyan = Color(0xFF65DDF0)
private val client = OkHttpClient.Builder()
    .connectTimeout(25, TimeUnit.SECONDS).readTimeout(0, TimeUnit.SECONDS)
    .writeTimeout(25, TimeUnit.SECONDS).build()

data class ChatMessage(val id: Long = System.currentTimeMillis(), val text: String, val user: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = bg, surface = panel, primary = pink, secondary = violet,
                onBackground = Color.White, onSurface = Color.White
            )) {
                val prefs = remember { securePrefs() }
                MiraApp(
                    loadConfig = { prefs.getString("config", "") ?: "" },
                    saveConfig = { prefs.edit().putString("config", it).apply() },
                    loadHistory = { prefs.getString("history", "[]") ?: "[]" },
                    saveHistory = { prefs.edit().putString("history", it).apply() }
                )
            }
        }
    }

    private fun securePrefs() = EncryptedSharedPreferences.create(
        this, "mira_secure",
        MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
}

@Composable
fun MiraApp(loadConfig: () -> String, saveConfig: (String) -> Unit, loadHistory: () -> String, saveHistory: (String) -> Unit) {
    val context = LocalContext.current
    var tab by remember { mutableStateOf("Home") }
    var configRaw by remember { mutableStateOf(loadConfig()) }
    var provider by remember { mutableStateOf("Gemini") }
    var apiKey by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("gemini-2.0-flash") }
    var baseUrl by remember { mutableStateOf("https://api.openai.com/v1") }
    var status by remember { mutableStateOf("Connect an AI provider to begin") }
    var busy by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var selectedCharacter by remember { mutableStateOf("Mochi") }
    var error by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val scope = rememberCoroutineScope()
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(Unit) {
        tts = TextToSpeech(context) { code -> if (code == TextToSpeech.SUCCESS) tts?.setLanguage(Locale.getDefault()) }
        onDispose { tts?.stop(); tts?.shutdown() }
    }

    LaunchedEffect(Unit) {
        try {
            if (configRaw.isNotBlank()) {
                val j = JSONObject(configRaw)
                provider = j.optString("provider", provider)
                apiKey = j.optString("key", "")
                model = j.optString("model", model)
                baseUrl = j.optString("baseUrl", baseUrl)
                status = "Saved API configuration loaded"
            }
            val arr = JSONArray(loadHistory())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                messages.add(ChatMessage(o.optLong("id"), o.optString("text"), o.optBoolean("user")))
            }
        } catch (_: Exception) { status = "Some saved data could not be loaded" }
        if (messages.isEmpty()) messages.add(ChatMessage(text = "Hi! I'm MIRA ✨ Your little AI companion. Add your API in API Center and let's talk.", user = false))
    }

    fun persistHistory() {
        val arr = JSONArray()
        messages.takeLast(250).forEach { arr.put(JSONObject().put("id", it.id).put("text", it.text).put("user", it.user)) }
        saveHistory(arr.toString())
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startSpeech(context, { input = it; listening = false }, { listening = false; error = it })
        else error = "Microphone permission was not granted"
    }

    fun startVoice() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            listening = true
            startSpeech(context, { input = it; listening = false }, { listening = false; error = it })
        } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun sendMessage() {
        val prompt = input.trim()
        if (prompt.isEmpty() || busy) return
        if (apiKey.isBlank()) { tab = "API Center"; error = "Add your API key first"; return }
        messages.add(ChatMessage(text = prompt, user = true))
        val answer = ChatMessage(text = "", user = false)
        messages.add(answer)
        input = ""; busy = true; error = ""; persistHistory()
        scope.launch {
            try {
                val historySnapshot = messages.dropLast(1).takeLast(20)
                val config = ApiConfig(provider, apiKey, model, baseUrl)
                withContext(Dispatchers.IO) {
                    streamAi(config, historySnapshot, selectedCharacter,
                        onChunk = { chunk -> withContextMain { 
                            val idx = messages.indexOfFirst { it.id == answer.id }
                            if (idx >= 0) messages[idx] = messages[idx].copy(text = messages[idx].text + chunk)
                        } },
                        onComplete = { }
                    )
                }
                val finalText = messages.firstOrNull { it.id == answer.id }?.text.orEmpty()
                if (finalText.isBlank()) {
                    val idx = messages.indexOfFirst { it.id == answer.id }
                    if (idx >= 0) messages[idx] = messages[idx].copy(text = "The provider returned an empty response.")
                }
                persistHistory()
            } catch (e: Exception) {
                val idx = messages.indexOfFirst { it.id == answer.id }
                if (idx >= 0) messages[idx] = messages[idx].copy(text = "Request failed: ${e.message ?: "Check your API settings and internet."}")
                persistHistory()
            } finally { busy = false }
        }
    }

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF21142F), bg, Color(0xFF090A14))))) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 17.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(36.dp).clip(CircleShape).background(Brush.linearGradient(listOf(pink, violet))), Alignment.Center) { Text("✦", fontSize = 23.sp, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("MIRA AI", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("YOUR LITTLE AI COMPANION", fontSize = 9.sp, color = cyan, letterSpacing = 1.4.sp)
                }
                Surface(color = panel2, shape = RoundedCornerShape(18.dp)) { Text("✦ PERSONAL", Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = cyan, fontSize = 9.sp) }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("Home", "Chat", "Characters", "API Center", "History", "Settings").forEach {
                    FilterChip(selected = tab == it, onClick = { tab = it }, label = { Text(it, fontSize = 11.sp) })
                }
            }
            when (tab) {
                "Home" -> HomeScreen(selectedCharacter, status, { tab = "Chat" }, { tab = "API Center" }, { tab = "Characters" })
                "Chat" -> ChatScreen(messages, input, { input = it }, busy, listening, ::sendMessage, ::startVoice,
                    { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mira-tts") }, { messages.clear(); persistHistory() })
                "Characters" -> CharactersScreen(selectedCharacter) { selectedCharacter = it }
                "API Center" -> ApiScreen(provider, { provider = it; model = if (it == "Gemini") "gemini-2.0-flash" else "gpt-4o-mini" },
                    apiKey, { apiKey = it }, model, { model = it }, baseUrl, { baseUrl = it }, status,
                    onSave = {
                        configRaw = JSONObject().put("provider", provider).put("key", apiKey.trim()).put("model", model.trim()).put("baseUrl", baseUrl.trim()).toString()
                        saveConfig(configRaw); status = "API configuration saved securely on this device"; error = ""
                    },
                    onTest = {
                        if (apiKey.isBlank() || model.isBlank()) { status = "Enter an API key and model first"; return@ApiScreen }
                        busy = true; status = "Testing live connection…"
                        scope.launch {
                            try {
                                val testConfig = ApiConfig(provider, apiKey, model, baseUrl)
                                val result = withContext(Dispatchers.IO) { nonStreamingTest(testConfig) }
                                status = "Connected ✓  ${result.take(70)}"
                            } catch (e: Exception) { status = "Connection failed: ${e.message}" }
                            finally { busy = false }
                        }
                    }, busy, error)
                "History" -> HistoryScreen(messages, { messages.clear(); persistHistory() }, { tab = "Chat" })
                else -> SettingsScreen(selectedCharacter, status, { tab = "API Center" }, { messages.clear(); persistHistory() })
            }
        }
    }
}

private suspend fun withContextMain(block: suspend () -> Unit) { withContext(Dispatchers.Main) { block() } }

private fun startSpeech(context: android.content.Context, onText: (String) -> Unit, onError: (String) -> Unit) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) { onError("Speech recognition is not available on this device"); return }
    val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
    recognizer.setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) { recognizer.destroy(); onError("Voice input failed (code $error). Try again.") }
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
            recognizer.destroy()
            if (text.isNotBlank()) onText(text) else onError("No speech was recognized")
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    })
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
    }
    recognizer.startListening(intent)
}

data class ApiConfig(val provider: String, val key: String, val model: String, val baseUrl: String)

private suspend fun streamAi(config: ApiConfig, history: List<ChatMessage>, character: String, onChunk: suspend (String) -> Unit, onComplete: () -> Unit) {
    val persona = when (character) {
        "Pip" -> "You are Pip, a playful, upbeat and encouraging companion. Keep explanations friendly and simple."
        "Nova" -> "You are Nova, a calm, clever and creative companion. Think carefully and explain ideas clearly."
        "Bubbles" -> "You are Bubbles, a gentle, patient and thoughtful companion. Be supportive and considerate."
        else -> "You are Mochi, a curious, kind and cheerful companion. Be warm, clear and useful."
    }
    val systemPrompt = "$persona You are part of MIRA AI. Be safe, honest, clear and useful."
    val requestJson: JSONObject
    val url: String
    val builder = Request.Builder()
    if (config.provider == "Gemini") {
        val contents = JSONArray()
        history.filter { it.text.isNotBlank() }.forEach { msg ->
            contents.put(JSONObject().put("role", if (msg.user) "user" else "model").put("parts", JSONArray().put(JSONObject().put("text", msg.text))))
        }
        requestJson = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", 0.7))
        url = "https://generativelanguage.googleapis.com/v1beta/models/${config.model}:streamGenerateContent?alt=sse&key=${config.key}"
    } else {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", systemPrompt))
        history.filter { it.text.isNotBlank() }.forEach { msg ->
            msgs.put(JSONObject().put("role", if (msg.user) "user" else "assistant").put("content", msg.text))
        }
        requestJson = JSONObject().put("model", config.model).put("messages", msgs).put("stream", true)
        url = config.baseUrl.trimEnd('/') + "/chat/completions"
        builder.header("Authorization", "Bearer ${config.key}")
    }
    val request = builder.url(url).post(requestJson.toString().toRequestBody("application/json".toMediaType())).build()
    client.newCall(request).execute().use { response ->
        val body = response.body ?: throw IOException("Empty response body")
        if (!response.isSuccessful) throw IOException("HTTP ${response.code}: ${body.string().take(500)}")
        val source = body.source()
        while (!source.exhausted()) {
            val line = source.readUtf8Line() ?: continue
            if (!line.startsWith("data:")) continue
            val data = line.removePrefix("data:").trim()
            if (data.isEmpty() || data == "[DONE]") continue
            try {
                val obj = JSONObject(data)
                val chunk = if (config.provider == "Gemini") {
                    obj.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text").orEmpty()
                } else {
                    obj.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")?.optString("content").orEmpty()
                }
                if (chunk.isNotEmpty()) onChunk(chunk)
            } catch (_: Exception) { /* Ignore non-content SSE frames */ }
        }
    }
    onComplete()
}

private fun nonStreamingTest(config: ApiConfig): String {
    val prompt = "Reply with the single word Connected."
    val json: JSONObject
    val request = Request.Builder()
    val url: String
    if (config.provider == "Gemini") {
        json = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
        url = "https://generativelanguage.googleapis.com/v1beta/models/${config.model}:generateContent?key=${config.key}"
    } else {
        json = JSONObject().put("model", config.model).put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        url = config.baseUrl.trimEnd('/') + "/chat/completions"
        request.header("Authorization", "Bearer ${config.key}")
    }
    val req = request.url(url).post(json.toString().toRequestBody("application/json".toMediaType())).build()
    client.newCall(req).execute().use {
        val body = it.body?.string().orEmpty()
        if (!it.isSuccessful) throw IOException("HTTP ${it.code}: ${body.take(350)}")
        return if (config.provider == "Gemini") JSONObject(body).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        else JSONObject(body).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
}

@Composable
fun HomeScreen(character: String, status: String, chat: () -> Unit, api: () -> Unit, chars: () -> Unit) {
    val infinite = rememberInfiniteTransition(label = "orb")
    val pulse by infinite.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "pulse")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(13.dp))
        Text("YOUR PERSONAL AI COMPANION", color = cyan, fontSize = 9.sp, letterSpacing = 2.2.sp)
        Spacer(Modifier.height(8.dp))
        Box(Modifier.size((196 * pulse).dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFFEC49F5).copy(alpha=.28f), Color(0xFF7045D8).copy(alpha=.15f), Color.Transparent))), Alignment.Center) {
            GlowingCharacter(character)
        }
        Text("Hello, I'm $character", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Your AI digital partner", color = Color.LightGray, fontSize = 12.sp)
        Spacer(Modifier.height(17.dp))
        Surface(color = panel.copy(alpha=.95f), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, violet.copy(alpha=.25f))) {
            Column(Modifier.padding(15.dp)) {
                Text("✦  READY WHEN YOU ARE", color = cyan, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                Spacer(Modifier.height(5.dp)); Text(status, color = Color.LightGray, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(11.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FeatureTile("Chat with MIRA", "Ask anything", "✧", Modifier.weight(1f), chat)
            FeatureTile("Meet characters", "Pick your buddy", "♡", Modifier.weight(1f), chars)
        }
        Spacer(Modifier.height(10.dp))
        FeatureTile("Connect your AI", "Gemini & compatible APIs", "⚙", Modifier.fillMaxWidth(), api)
        Spacer(Modifier.height(15.dp))
    }
}

@Composable
fun GlowingCharacter(character: String) {
    val orb = character == "Nova"
    Box(Modifier.size(156.dp).clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFFEF45E9), Color(0xFF8738D9), Color(0xFF231C46)))), Alignment.Center) {
        if (orb) {
            Text("✧", fontSize = 90.sp, color = Color(0xFFFFB5FF))
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(106.dp, 82.dp).clip(RoundedCornerShape(32.dp)).background(Brush.linearGradient(listOf(Color(0xFFB9C7E9), Color(0xFF625A9D), Color(0xFF252C54)))), Alignment.Center) {
                    Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                        Box(Modifier.size(13.dp).clip(CircleShape).background(Color(0xFFBDFBFF)).shadow(8.dp, CircleShape))
                        Box(Modifier.size(13.dp).clip(CircleShape).background(Color(0xFFBDFBFF)).shadow(8.dp, CircleShape))
                    }
                }
                Spacer(Modifier.height(5.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                    Box(Modifier.size(22.dp, 30.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF7669B5)))
                    Box(Modifier.size(22.dp, 30.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF7669B5)))
                }
            }
        }
    }
}

@Composable
fun FeatureTile(title: String, sub: String, symbol: String, modifier: Modifier, click: () -> Unit) {
    Surface(onClick = click, modifier = modifier, color = panel, shape = RoundedCornerShape(19.dp), border = BorderStroke(1.dp, violet.copy(alpha=.22f))) {
        Column(Modifier.padding(14.dp)) {
            Text(symbol, color = pink, fontSize = 22.sp); Spacer(Modifier.height(7.dp))
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(sub, color = Color.LightGray, fontSize = 10.sp)
        }
    }
}

@Composable
fun ChatScreen(messages: List<ChatMessage>, input: String, setInput: (String)->Unit, busy: Boolean, listening: Boolean, send: ()->Unit, voice: ()->Unit, speak: (String)->Unit, clear: ()->Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal=13.dp, vertical=8.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("MIRA Chat", fontSize=20.sp, fontWeight=FontWeight.Bold); Text("Private companion conversation", color=Color.LightGray, fontSize=10.sp) }
            IconButton(onClick=clear) { Icon(Icons.Default.DeleteOutline, "Clear chat", tint=Color.LightGray) }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical=9.dp), verticalArrangement=Arrangement.spacedBy(9.dp)) {
            items(messages, key={it.id}) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement=if(msg.user) Arrangement.End else Arrangement.Start, verticalAlignment=Alignment.Bottom) {
                    if (!msg.user) Text("✿", color=pink, fontSize=17.sp, modifier=Modifier.padding(end=5.dp))
                    Surface(color=if(msg.user) Color(0xFF48305E) else panel, shape=RoundedCornerShape(18.dp), modifier=Modifier.widthIn(max=300.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(msg.text.ifBlank { "MIRA is thinking…" }, fontSize=13.sp, lineHeight=19.sp)
                            if (!msg.user && msg.text.isNotBlank()) Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.End) {
                                TextButton(onClick={speak(msg.text)}) { Icon(Icons.Default.VolumeUp, null, modifier=Modifier.size(15.dp)); Text(" Speak", fontSize=10.sp) }
                            }
                        }
                    }
                }
            }
            if (busy) item { Text("MIRA is typing…", color=cyan, fontSize=11.sp) }
        }
        Surface(color=panel2, shape=RoundedCornerShape(23.dp), modifier=Modifier.fillMaxWidth()) {
            Row(Modifier.padding(6.dp), verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick=voice) { Icon(if(listening) Icons.Default.Mic else Icons.Default.MicNone, "Voice input", tint=if(listening) pink else Color.LightGray) }
                TextField(value=input, onValueChange=setInput, modifier=Modifier.weight(1f), placeholder={Text("Message MIRA…", fontSize=12.sp)}, maxLines=4, colors=TextFieldDefaults.colors(focusedContainerColor=Color.Transparent, unfocusedContainerColor=Color.Transparent, focusedIndicatorColor=Color.Transparent, unfocusedIndicatorColor=Color.Transparent))
                IconButton(onClick=send, enabled=!busy && input.isNotBlank()) { Icon(Icons.Default.Send, "Send", tint=pink) }
            }
        }
    }
}

@Composable
fun CharactersScreen(selected: String, select: (String)->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(17.dp)) {
        Text("Character Studio", fontSize=22.sp, fontWeight=FontWeight.Bold)
        Text("Choose the personality you want to chat with", color=Color.LightGray, fontSize=11.sp)
        Spacer(Modifier.height(14.dp))
        listOf(Triple("Mochi","🤖","Curious, kind and cheerful"), Triple("Pip","🐣","Playful and encouraging"), Triple("Nova","🐱","Calm, clever and creative"), Triple("Bubbles","🐼","Gentle and thoughtful")).forEach { (name, emoji, desc) ->
            Surface(onClick={select(name)}, color=if(selected==name) Color(0xFF39254F) else panel, shape=RoundedCornerShape(19.dp), border=BorderStroke(1.dp, if(selected==name) pink else Color.Transparent), modifier=Modifier.fillMaxWidth().padding(bottom=10.dp)) {
                Row(Modifier.padding(15.dp), verticalAlignment=Alignment.CenterVertically) {
                    Text(emoji, fontSize=35.sp); Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) { Text(name, fontWeight=FontWeight.Bold); Text(desc, color=Color.LightGray, fontSize=11.sp) }
                    if(selected==name) Icon(Icons.Default.CheckCircle, null, tint=cyan)
                }
            }
        }
    }
}

@Composable
fun ApiScreen(provider: String, setProvider:(String)->Unit, key:String, setKey:(String)->Unit, model:String, setModel:(String)->Unit, base:String, setBase:(String)->Unit, status:String, onSave:()->Unit, onTest:()->Unit, busy:Boolean, error:String) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(17.dp)) {
        Text("API Control Center", fontSize=22.sp, fontWeight=FontWeight.Bold)
        Text("Connect your own AI brain", color=Color.LightGray, fontSize=11.sp)
        Spacer(Modifier.height(14.dp))
        Text("AI PROVIDER", color=cyan, fontSize=10.sp, letterSpacing=1.4.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf("Gemini","OpenAI-compatible").forEach { FilterChip(selected=provider==it, onClick={setProvider(it)}, label={Text(it, fontSize=11.sp)}) }
        }
        if(provider=="OpenAI-compatible") ApiField("Base URL",base,setBase,"https://api.openai.com/v1")
        else Text("Gemini uses Google's Generative Language API endpoint.", color=Color.LightGray, fontSize=10.sp)
        ApiField("API Key",key,setKey,"Paste your private API key",true)
        ApiField("Model ID",model,setModel,if(provider=="Gemini") "gemini-2.0-flash" else "gpt-4o-mini")
        Spacer(Modifier.height(12.dp))
        Text(status, color=if(status.contains("Connected") || status.contains("saved",true)) cyan else Color.LightGray, fontSize=11.sp)
        if(error.isNotBlank()) Text(error, color=Color(0xFFFF9A9A), fontSize=11.sp)
        Spacer(Modifier.height(10.dp))
        Button(onClick=onSave, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=pink), shape=RoundedCornerShape(14.dp)) { Text("Save API Configuration") }
        OutlinedButton(onClick=onTest, enabled=!busy, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(14.dp)) { Text(if(busy) "Testing…" else "Test Live API Connection") }
        Spacer(Modifier.height(10.dp))
        Surface(color=panel, shape=RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(13.dp)) {
                Text("API SECURITY", color=cyan, fontSize=10.sp, fontWeight=FontWeight.Bold)
                Text("Your key is stored in Android encrypted preferences. Never commit API keys to GitHub. Direct mobile API use can expose keys to a modified device; use a backend proxy before public distribution.", color=Color.LightGray, fontSize=10.sp, lineHeight=15.sp)
            }
        }
    }
}

@Composable
fun ApiField(label:String, value:String, change:(String)->Unit, hint:String, secret:Boolean=false) {
    Spacer(Modifier.height(11.dp)); Text(label, color=cyan, fontSize=11.sp)
    TextField(value=value, onValueChange=change, modifier=Modifier.fillMaxWidth(), placeholder={Text(hint, fontSize=11.sp)}, singleLine=true, visualTransformation=if(secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None, colors=TextFieldDefaults.colors(focusedContainerColor=panel2, unfocusedContainerColor=panel2, focusedIndicatorColor=pink, unfocusedIndicatorColor=Color.Transparent))
}

@Composable
fun HistoryScreen(messages:List<ChatMessage>, clear:()->Unit, open:()->Unit) {
    Column(Modifier.fillMaxSize().padding(17.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) { Text("Chat History", fontSize=21.sp, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f)); TextButton(onClick=clear) { Text("Clear all") } }
        Text("Saved locally on this device • ${messages.size} messages", color=Color.LightGray, fontSize=10.sp)
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.weight(1f)) { items(messages) { Text((if(it.user) "YOU  " else "MIRA  ")+it.text, Modifier.fillMaxWidth().clickable { open() }.padding(vertical=8.dp), fontSize=12.sp, lineHeight=17.sp) } }
        Button(onClick=open, modifier=Modifier.fillMaxWidth()) { Text("Continue conversation") }
    }
}

@Composable
fun SettingsScreen(character:String, status:String, api:()->Unit, clear:()->Unit) {
    Column(Modifier.fillMaxSize().padding(17.dp)) {
        Text("Settings", fontSize=22.sp, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        FeatureTile("API Center", "Manage providers and keys", "⚙", Modifier.fillMaxWidth(), api)
        Spacer(Modifier.height(10.dp))
        FeatureTile("Clear chat history", "Delete locally saved messages", "⌫", Modifier.fillMaxWidth(), clear)
        Spacer(Modifier.height(14.dp))
        Text("Selected companion: $character", color=Color.LightGray, fontSize=12.sp)
        Text("Provider status: $status", color=Color.LightGray, fontSize=11.sp)
        Spacer(Modifier.height(12.dp))
        Text("MIRA AI 1.1.0 • Android companion", color=cyan, fontSize=10.sp)
    }
}
