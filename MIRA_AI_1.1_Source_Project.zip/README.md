# MIRA AI 1.1 — Android AI Companion

Android-first native Kotlin + Jetpack Compose AI companion. Inspired by the user's reference image's dark premium violet/magenta visual direction, but uses original UI and artwork rather than copying Grok branding or proprietary assets.

## Implemented in this source
- Native Android app (Kotlin + Compose), dark responsive UI
- Original stylized companion illustration built with Compose shapes, pulsing glow, character selection
- Character selection: Mochi, Pip, Nova, Bubbles; character-specific system prompt is sent with each chat request
- Gemini `streamGenerateContent` SSE integration
- OpenAI-compatible `/chat/completions` streaming integration
- Provider/model/base URL/API key configuration
- Live API connection test (non-streaming validation request)
- API configuration encrypted at rest with AndroidX EncryptedSharedPreferences
- Persistent local chat history (encrypted preferences)
- Speech input via Android SpeechRecognizer (microphone runtime permission)
- Text-to-speech for assistant messages
- Send, clear history, speak response, API save/test, navigation controls
- GitHub Actions debug APK build artifact

## API setup
1. Open **API Center**.
2. Choose Gemini or OpenAI-compatible.
3. Enter API key and model ID.
4. For OpenAI-compatible, enter the provider's API base URL (usually `/v1`).
5. Save, then tap **Test Live API Connection**.
6. Return to Chat and send a message.

Gemini default model is `gemini-2.0-flash`. OpenAI-compatible default is `gpt-4o-mini`; use a model supported by your provider. The API test makes a real network request. The chat uses SSE streaming for both provider paths.

## Build APK on GitHub
1. Create a new GitHub repository.
2. Upload the contents of this ZIP to the repository root, including the hidden `.github` folder.
3. Open **Actions** → **Build MIRA AI APK**.
4. Run workflow (or push to `main`).
5. Wait for the workflow to finish successfully.
6. Open the run and download **MIRA-AI-debug-apk** from Artifacts.
7. Extract the artifact ZIP and install `app-debug.apk`.

## Verification status and limitations
This source package was inspected for feature wiring, but it has NOT been compiled or run on an Android emulator/device in this environment because Android SDK and Gradle are not installed here. GitHub Actions is configured to perform the actual compile. Do not consider the APK verified until that workflow succeeds and the APK is installed/tested.

Direct client-side API requests require the user to provide their own API key. Encrypted preferences protect data at rest, but a determined attacker can still extract keys from a modified/rooted device or instrumented app. For a publicly distributed app, route requests through a secure backend proxy with authentication, quotas and rate limits. Never commit API keys to GitHub.

Voice recognition depends on an installed Android speech recognition service and network/device support. Text-to-speech depends on an installed TTS engine. The app reports availability/errors rather than pretending these services are always present.

Not included: login/cloud sync, image/file uploads, multiple named conversation threads, production signing, store deployment, or a real 3D model. The companion illustration is a Compose-drawn original stylized robot with a pulsing glow, not a 3D asset.
