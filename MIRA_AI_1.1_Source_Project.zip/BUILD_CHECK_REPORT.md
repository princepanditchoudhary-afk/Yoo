# MIRA AI 1.1 — Package Check

## Package contents
- Native Android project using Kotlin and Jetpack Compose.
- Home, Chat, Characters, API Center, History, Settings screens.
- Gemini streaming request path (`streamGenerateContent`, SSE parsing).
- OpenAI-compatible streaming request path (`/chat/completions`, SSE parsing).
- Non-streaming live API test button.
- API configuration and local chat history stored through AndroidX EncryptedSharedPreferences.
- Android SpeechRecognizer input and TextToSpeech output.
- Character-specific persona prompts for Mochi, Pip, Nova and Bubbles.
- GitHub Actions workflow to compile and upload a debug APK artifact.

## Checks performed for this ZIP
- Confirmed required project files exist.
- Confirmed manifest XML parses.
- Confirmed Gradle Kotlin DSL files and workflow are included.
- Confirmed source contains the integration paths listed above.
- Confirmed ZIP archive can be opened and its entries read.

## Not verified
- No Android SDK / Gradle installation was available in the build environment, so `assembleDebug` was not run here.
- No emulator or physical-device runtime tests were performed.
- No real API keys were supplied; Gemini/OpenAI-compatible requests were not live-tested.
- Speech recognition and TTS depend on Android device services and were not device-tested.

This is a source project intended for GitHub Actions APK building, not a prebuilt or verified APK. A feature's code path being present does not prove successful runtime behavior.
